// pattern: Functional Core

//! Direct f64 complex QMF reference transform from ETSI TS 103 420 clause 7.

use num_complex::Complex64;
use std::f64::consts::PI;
use std::sync::OnceLock;

/// Number of complex QMF subbands mandated by clause 7.4.
pub const QMF_BANDS: usize = 64;
/// Fixed causal latency of the normative analysis/synthesis identity path.
pub const QMF_ROUNDTRIP_LATENCY_SAMPLES: usize = 577;
/// Length of the normative prototype and analysis state.
pub const QMF_LENGTH: usize = 640;
const SYNTHESIS_LENGTH: usize = 2 * QMF_LENGTH;


#[allow(dead_code)]
mod generated {
    include!("generated_etsi_tables.rs");
}

fn prototype_f64() -> &'static [f64] {
    static PROTOTYPE: OnceLock<Box<[f64]>> = OnceLock::new();
    PROTOTYPE.get_or_init(|| {
        generated::PROT64
            .iter()
            .copied()
            .map(f64::from)
            .collect::<Vec<_>>()
            .into_boxed_slice()
    })
}

// VANTA, 2026-09-08: the same complex modulation expressed as a 128-point
// inverse FFT. No PCM precision reduction; phase conventions follow the
// original direct equations. Plans and modulation factors are shared read-only.
fn inverse_plan() -> &'static std::sync::Arc<dyn rustfft::Fft<f64>> {
    static PLAN: OnceLock<std::sync::Arc<dyn rustfft::Fft<f64>>> = OnceLock::new();
    PLAN.get_or_init(|| rustfft::FftPlanner::new().plan_fft_inverse(128))
}
fn modulation() -> &'static [Complex64; 128] {
    static TABLE: OnceLock<[Complex64; 128]> = OnceLock::new();
    TABLE.get_or_init(|| std::array::from_fn(|n| Complex64::from_polar(1.0, PI*n as f64/128.0)))
}
fn analysis_rotation() -> &'static [Complex64; 64] {
    static TABLE: OnceLock<[Complex64; 64]> = OnceLock::new();
    TABLE.get_or_init(|| std::array::from_fn(|k| Complex64::from_polar(1.0, -PI*(k as f64+0.5)/128.0)))
}
fn synthesis_rotation() -> &'static [Complex64; 64] {
    static TABLE: OnceLock<[Complex64; 64]> = OnceLock::new();
    TABLE.get_or_init(|| std::array::from_fn(|k| Complex64::from_polar(1.0, -PI*(2*k+1) as f64*255.0/256.0)))
}

/// Stateful, direct-equation f64 implementation of the clause 7 transform pair.
#[derive(Clone, Debug)]
pub struct ReferenceQmf64F64 {
    analysis_state: [f64; QMF_LENGTH],
    synthesis_state: [f64; SYNTHESIS_LENGTH],
}

impl ReferenceQmf64F64 {
    /// Creates a transform with both normative history buffers initialized to zero.
    #[must_use]
    pub fn new() -> Self {
        Self {
            analysis_state: [0.0; QMF_LENGTH],
            synthesis_state: [0.0; SYNTHESIS_LENGTH],
        }
    }

    /// Clears both analysis and synthesis history, for stream discontinuities.
    pub fn reset(&mut self) {
        self.analysis_state.fill(0.0);
        self.synthesis_state.fill(0.0);
    }

    /// Applies clauses 7.2 pseudocode 8 through 12 to one 64-sample block.
    #[must_use]
    pub fn analyze(&mut self, pcm: &[f64; QMF_BANDS]) -> [Complex64; QMF_BANDS] {
        self.analysis_state
            .copy_within(0..QMF_LENGTH - QMF_BANDS, QMF_BANDS);
        for (destination, sample) in self.analysis_state[..QMF_BANDS]
            .iter_mut()
            .zip(pcm.iter().rev())
        {
            *destination = *sample;
        }

        let mut folded = [0.0; 2 * QMF_BANDS];
        let prototype = prototype_f64();
        for (index, value) in folded.iter_mut().enumerate() {
            for fold in 0..QMF_LENGTH / (2 * QMF_BANDS) {
                let window_index = index + fold * 2 * QMF_BANDS;
                *value += self.analysis_state[window_index] * prototype[window_index];
            }
        }

        let mut spectrum: [Complex64; 128] = std::array::from_fn(|n| modulation()[n] * folded[n]);
        inverse_plan().process(&mut spectrum);
        let subbands = std::array::from_fn(|k| spectrum[k] * analysis_rotation()[k]);
        subbands
    }

    /// Applies clauses 7.3 pseudocode 13 through 17 to one complex timeslot.
    #[must_use]
    pub fn synthesize(&mut self, subbands: &[Complex64; QMF_BANDS]) -> [f64; QMF_BANDS] {
        self.synthesis_state
            .copy_within(0..SYNTHESIS_LENGTH - 2 * QMF_BANDS, 2 * QMF_BANDS);

        let mut spectrum = [Complex64::ZERO; 128];
        for k in 0..64 { spectrum[k] = subbands[k] * synthesis_rotation()[k]; }
        inverse_plan().process(&mut spectrum);
        for j in 0..128 { self.synthesis_state[j] = (spectrum[j] * modulation()[j]).re / 64.0; }

        let mut pcm = [0.0; QMF_BANDS];
        let prototype = prototype_f64();
        for (timeslot, output) in pcm.iter_mut().enumerate() {
            for fold in 0..QMF_LENGTH / QMF_BANDS {
                let window_index = fold * QMF_BANDS + timeslot;
                let synthesis_index = if fold % 2 == 0 {
                    2 * fold * QMF_BANDS + timeslot
                } else {
                    2 * (fold - 1) * QMF_BANDS + 3 * QMF_BANDS + timeslot
                };
                *output += self.synthesis_state[synthesis_index] * prototype[window_index];
            }
        }
        pcm
    }
}

impl Default for ReferenceQmf64F64 {
    fn default() -> Self {
        Self::new()
    }
}
